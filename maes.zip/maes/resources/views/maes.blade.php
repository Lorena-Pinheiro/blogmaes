<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dia das Mães</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="flip-card">
            <div class="flip-card-inner">
                <div class="flip-card-front">
                    <img src="https://www.fashionbubbles.com/wp-content/uploads/2023/03/frases-dia-das-maes-capa.jpg" alt="Avatar" >
                </div>
                <div class="flip-card-back">
                    <h1>Feliz Dia das Mães</h1>
                    <p>(Para a mais linda de todas e que torna a minha vida mais alegre!)</p>
                </div>
            </div>
        </div>
    </body>
</html>